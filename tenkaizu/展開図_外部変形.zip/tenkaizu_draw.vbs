'==============================================================
' Jw_cad �O���ό` : �W�J�}����}����
'
'   tenkaizu_data.txt�i���̃t�@�C���Ɠ����t�H���_�j�̍�}�f�[�^��
'   jwc_temp.txt �ɏ����o���� Jw_cad �ɕ`�����܂��B
'   �uREM #1�v�Ŏw�����ꂽ�_ hp1 �������Ƃ��Ĕz�u���܂��B
'   �w���_�������Ƃ��͐}�ʌ��_�i�p�������j�������ɂ��܂��B
'==============================================================
Option Explicit

Dim gFso : Set gFso = CreateObject("Scripting.FileSystemObject")

Dim scriptDir : scriptDir = gFso.GetParentFolderName(WScript.ScriptFullName)
Dim dataPath  : dataPath  = gFso.BuildPath(scriptDir, "tenkaizu_data.txt")
Dim tempPath  : tempPath  = FindTemp()

If tempPath = "" Then
    WScript.Echo "jwc_temp.txt ��������܂���B" & vbCrLf & _
                 "Jw_cad �̊O���ό`������s���Ă��������B"
    WScript.Quit 1
End If
If Not gFso.FileExists(dataPath) Then
    WScript.Echo "tenkaizu_data.txt ��������܂���B" & vbCrLf & _
                 "�o�b�`�t�@�C���Ɠ����t�H���_�ɒu���Ă��������B"
    WScript.Quit 1
End If

'--- �w���_ hp1 ��ǂ� ----------------------------------------
Dim ox, oy : ox = 0 : oy = 0
Dim lines, i, t, toks
lines = ReadAllLines(tempPath)
For i = 0 To UBound(lines)
    t = Trim(lines(i))
    If Left(t, 4) = "hp1 " Then
        toks = Tokenize(Mid(t, 5))
        If UBound(toks) >= 1 Then
            ox = ParseNum(toks(0))
            oy = ParseNum(toks(1))
        End If
        Exit For
    End If
Next

'--- ��}�f�[�^�𕽍s�ړ����ďo�� ------------------------------
Dim out : out = ""
lines = ReadAllLines(dataPath)
For i = 0 To UBound(lines)
    t = Trim(lines(i))
    If t <> "" And Left(t, 1) <> "#" Then
        out = out & Shift(t, ox, oy) & vbCrLf
    End If
Next
WriteAllText tempPath, out
WScript.Quit 0

'==============================================================
' 1 �s�𕽍s�ړ�����
'   �uci x y r�v�uch �n�_X �n�_Y ����X ����Y "������v�ux1 y1 x2 y2�v���ΏہB
'   ch �̑�3�E4�͕�����̒����x�N�g���Ȃ̂ŁA�n�_�������ړ�����B
'   �����s�ily / lc / lt / cn �c�j�͂��̂܂ܕԂ��B
'==============================================================
Function Shift(ByVal t, ByVal ox, ByVal oy)
    Dim toks, n, i

    If Left(t, 3) = "ci " Then
        toks = Tokenize(Mid(t, 4))
        If UBound(toks) >= 2 Then
            Shift = "ci " & FmtNum(ParseNum(toks(0)) + ox) & " " & _
                            FmtNum(ParseNum(toks(1)) + oy) & " " & toks(2)
            Exit Function
        End If

    ElseIf Left(t, 3) = "ch " Then
        Dim body, nums(3), st, cnt, c, rest
        body = Mid(t, 4) : cnt = 0 : i = 1 : rest = ""
        Do While i <= Len(body) And cnt < 4
            Do While i <= Len(body)
                c = Mid(body, i, 1)
                If c <> " " And c <> vbTab Then Exit Do
                i = i + 1
            Loop
            st = i
            Do While i <= Len(body)
                c = Mid(body, i, 1)
                If c = " " Or c = vbTab Then Exit Do
                i = i + 1
            Loop
            If i <= st Then Exit Do
            nums(cnt) = ParseNum(Mid(body, st, i - st))
            cnt = cnt + 1
        Loop
        If cnt = 4 Then
            rest = LTrim(Mid(body, i))
            ' ��3�E4�t�B�[���h�͕�����̒����x�N�g���Ȃ̂ŕ��s�ړ����Ȃ�
            Shift = "ch " & FmtNum(nums(0) + ox) & " " & FmtNum(nums(1) + oy) & " " & _
                            FmtNum(nums(2)) & " " & FmtNum(nums(3)) & " " & rest
            Exit Function
        End If

    Else
        toks = Tokenize(t)
        n = UBound(toks)
        If n = 3 Then
            If IsNumToken(toks(0)) And IsNumToken(toks(1)) And _
               IsNumToken(toks(2)) And IsNumToken(toks(3)) Then
                Shift = FmtNum(ParseNum(toks(0)) + ox) & " " & _
                        FmtNum(ParseNum(toks(1)) + oy) & " " & _
                        FmtNum(ParseNum(toks(2)) + ox) & " " & _
                        FmtNum(ParseNum(toks(3)) + oy)
                Exit Function
            End If
        End If
    End If

    Shift = t
End Function

'--- jwc_temp.txt ��T�� --------------------------------------
Function FindTemp()
    Dim cands, p, sh
    Set sh = CreateObject("WScript.Shell")
    cands = Array(gFso.BuildPath(sh.CurrentDirectory, "jwc_temp.txt"), _
                  gFso.BuildPath(scriptDir, "jwc_temp.txt"))
    For Each p In cands
        If gFso.FileExists(p) Then FindTemp = p : Exit Function
    Next
    FindTemp = ""
End Function

'--- �󔒋�؂�ɕ����� ---------------------------------------
Function Tokenize(s)
    Dim res(), n, i, st, c
    ReDim res(31) : n = 0 : i = 1
    Do While i <= Len(s)
        Do While i <= Len(s)
            c = Mid(s, i, 1)
            If c <> " " And c <> vbTab Then Exit Do
            i = i + 1
        Loop
        If i > Len(s) Then Exit Do
        st = i
        Do While i <= Len(s)
            c = Mid(s, i, 1)
            If c = " " Or c = vbTab Then Exit Do
            i = i + 1
        Loop
        If n > UBound(res) Then ReDim Preserve res(n * 2 + 1)
        res(n) = Mid(s, st, i - st)
        n = n + 1
    Loop
    If n = 0 Then
        Tokenize = Array()
    Else
        ReDim Preserve res(n - 1)
        Tokenize = res
    End If
End Function

Function IsNumToken(s)
    Dim i, c, seen
    s = Trim(s) : seen = False
    If s = "" Then IsNumToken = False : Exit Function
    For i = 1 To Len(s)
        c = Mid(s, i, 1)
        If c >= "0" And c <= "9" Then
            seen = True
        ElseIf c = "." Then
        ElseIf (c = "-" Or c = "+") And i = 1 Then
        Else
            IsNumToken = False : Exit Function
        End If
    Next
    IsNumToken = seen
End Function

Function ParseNum(s)
    Dim v
    s = Trim(s)
    On Error Resume Next
    v = CDbl(s)
    If Err.Number <> 0 Then Err.Clear : v = 0
    On Error GoTo 0
    ParseNum = v
End Function

Function FmtNum(v)
    Dim s
    s = CStr(Round(v, 2))
    If InStr(s, ",") > 0 Then s = Replace(s, ",", ".")
    FmtNum = s
End Function

'--- �t�@�C�����o�́iShift_JIS�j--------------------------------
Function ReadAllLines(path)
    Dim st, f, txt
    On Error Resume Next
    Set st = CreateObject("ADODB.Stream")
    If Err.Number = 0 Then
        st.Type = 2 : st.Charset = "shift_jis" : st.Open
        st.LoadFromFile path
        txt = st.ReadText(-1)
        st.Close
    End If
    If Err.Number <> 0 Or IsEmpty(txt) Then
        Err.Clear
        Set f = gFso.OpenTextFile(path, 1, False)
        If Not f.AtEndOfStream Then txt = f.ReadAll Else txt = ""
        f.Close
    End If
    On Error GoTo 0
    txt = Replace(txt, vbCrLf, vbLf)
    txt = Replace(txt, vbCr, vbLf)
    ReadAllLines = Split(txt, vbLf)
End Function

Sub WriteAllText(path, txt)
    Dim st, f, done
    done = False
    On Error Resume Next
    Set st = CreateObject("ADODB.Stream")
    If Err.Number = 0 Then
        st.Type = 2 : st.Charset = "shift_jis" : st.Open
        st.WriteText txt
        st.SaveToFile path, 2
        st.Close
        If Err.Number = 0 Then done = True
    End If
    If Not done Then
        Err.Clear
        Set f = gFso.CreateTextFile(path, True, False)
        f.Write txt
        f.Close
    End If
    On Error GoTo 0
End Sub
